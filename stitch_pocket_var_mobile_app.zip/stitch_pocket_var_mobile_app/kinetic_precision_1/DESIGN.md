---
name: Kinetic Precision
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#c4c9ac'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#8e9379'
  outline-variant: '#444933'
  surface-tint: '#abd600'
  primary: '#ffffff'
  on-primary: '#283500'
  primary-container: '#c3f400'
  on-primary-container: '#556d00'
  inverse-primary: '#506600'
  secondary: '#ffb59c'
  on-secondary: '#5c1900'
  secondary-container: '#ff5708'
  on-secondary-container: '#511500'
  tertiary: '#ffffff'
  on-tertiary: '#21323e'
  tertiary-container: '#d2e5f5'
  on-tertiary-container: '#556774'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#c3f400'
  primary-fixed-dim: '#abd600'
  on-primary-fixed: '#161e00'
  on-primary-fixed-variant: '#3c4d00'
  secondary-fixed: '#ffdbcf'
  secondary-fixed-dim: '#ffb59c'
  on-secondary-fixed: '#390c00'
  on-secondary-fixed-variant: '#822700'
  tertiary-fixed: '#d2e5f5'
  tertiary-fixed-dim: '#b6c9d8'
  on-tertiary-fixed: '#0b1d29'
  on-tertiary-fixed-variant: '#374956'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.1em
  data-numeric:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  touch-target-min: 48px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 32px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 24px
---

## Brand & Style

The design system is engineered for high-stakes athletic environments where split-second decisions and data accuracy are paramount. The brand personality is **rugged, technical, and authoritative**, mirroring the precision of professional officiating tools.

The visual style is **Tech-Minimalism**. It prioritizes extreme legibility and high-contrast signaling over decorative elements. By utilizing a deep black canvas, the interface recedes to let video content and data visualizations take center stage. The aesthetic is inspired by tactical equipment and high-performance automotive telemetry, ensuring the UI feels like a professional-grade instrument rather than a consumer app.

## Colors

The palette is optimized for low-light environments (stadiums, sidelines) and high-speed recognition.

- **Primary (Electric Lime):** Used exclusively for "Active" states, affirmative actions, and successful VAR checks. Its high luminance ensures visibility against dark backgrounds.
- **Secondary (Ignite Orange):** Reserved for alerts, warnings, and time-sensitive "Live" indicators.
- **Neutrals:** A range of deep charcoals and blacks are used to create structural hierarchy without introducing chromatic noise.
- **Functional Colors:** Error states utilize the secondary orange; success states utilize the primary lime.

## Typography

This design system utilizes **Inter** for its exceptional legibility and neutral, professional character. For data-heavy readouts, timestamps, and coordinates, **JetBrains Mono** is introduced to provide a technical, monospaced "instrument" feel.

Large headlines use tight tracking and heavy weights to command authority. Body text maintains generous line height to ensure readability during movement. The `label-caps` style is used for non-interactive metadata to distinguish it from actionable text.

## Layout & Spacing

The layout follows a **8px rhythmic grid** to ensure mathematical balance. 

- **Touch-First Philosophy:** A strict minimum touch target of 48px is enforced for all interactive elements to accommodate gloved hands or rapid use in high-pressure environments.
- **Fluid Content Zones:** Video feeds use a 16:9 aspect ratio container that spans the full width of the viewport. Data panels utilize a 12-column grid on desktop, collapsing to a single-column stack on mobile.
- **Safe Zones:** 16px margins are maintained on mobile to prevent accidental triggers near screen edges.

## Elevation & Depth

To maintain a "rugged" and "flat" aesthetic, this design system avoids soft ambient shadows. Instead, it uses **Tonal Layering and Border Definition**:

1.  **Level 0 (Base):** Pure Black (#000000).
2.  **Level 1 (Cards/Panels):** Deep Charcoal (#121212) with a 1px solid border (#2A2A2A).
3.  **Level 2 (Modals/Overlays):** Dark Gray (#1A1A1A) with a primary color accent border (1px).

This approach creates a clear hierarchy of information without the "mushiness" of traditional shadows, ensuring the UI feels sharp and hardware-integrated.

## Shapes

The design system uses **Soft (0.25rem)** roundedness to strike a balance between precision and modern ergonomics. 

- **Standard Elements:** Buttons, inputs, and small cards use a 4px (0.25rem) radius.
- **Large Containers:** Main video viewports and large dashboard cards use 8px (0.5rem).
- **Interactive Indicators:** Small status pips and "Live" indicators may use a full circle/pill shape for instant recognition.

Sharp corners are avoided to prevent the UI from feeling dated, while overly rounded "bubbly" shapes are rejected to maintain the professional, tactical tone.

## Components

### Buttons
- **Primary:** Electric Lime background, Black text. High-contrast, bold weight.
- **Secondary:** Ghost style. 1px White border, White text.
- **Destructive/Critical:** Ignite Orange background, White text.
- **Sizing:** Always 48px minimum height.

### Cards
- Background: #121212.
- Border: 1px solid #2A2A2A.
- Active State: Border changes to Electric Lime.

### Input Fields
- Dark background (#0A0A0A). 
- Bottom-border only (2px) or full 1px border. 
- Focus state: Border glows with 2px Electric Lime.

### Chips & Badges
- Used for "In Review," "Confirmed," and "Overturned" statuses.
- Use JetBrains Mono for badge text to emphasize the "data" aspect.

### Lists
- High-density rows with 16px vertical padding. 
- Separated by 1px #1A1A1A dividers.

### Specific Sports-Tech Components
- **The Scrub-Bar:** A heavy-duty video timeline with large handle targets and frame-by-frame increments marked with JetBrains Mono timestamps.
- **Decision Overlay:** Full-screen translucent black overlay with high-impact Display-style typography for the final VAR verdict.