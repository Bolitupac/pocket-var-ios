---
name: Kinetic Precision
colors:
  surface: '#121414'
  surface-dim: '#121414'
  surface-bright: '#37393a'
  surface-container-lowest: '#0c0f0f'
  surface-container-low: '#1a1c1c'
  surface-container: '#1e2020'
  surface-container-high: '#282a2b'
  surface-container-highest: '#333535'
  on-surface: '#e2e2e2'
  on-surface-variant: '#b9cbb9'
  inverse-surface: '#e2e2e2'
  inverse-on-surface: '#2f3131'
  outline: '#849584'
  outline-variant: '#3b4b3d'
  surface-tint: '#00e476'
  primary: '#f0ffee'
  on-primary: '#003919'
  primary-container: '#00ff85'
  on-primary-container: '#007137'
  inverse-primary: '#006d35'
  secondary: '#c8c6c5'
  on-secondary: '#313030'
  secondary-container: '#474746'
  on-secondary-container: '#b7b5b4'
  tertiary: '#fdfafa'
  on-tertiary: '#303030'
  tertiary-container: '#e0dedd'
  on-tertiary-container: '#626261'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#61ff97'
  primary-fixed-dim: '#00e476'
  on-primary-fixed: '#00210c'
  on-primary-fixed-variant: '#005227'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c8c6c5'
  on-secondary-fixed: '#1c1b1b'
  on-secondary-fixed-variant: '#474746'
  tertiary-fixed: '#e4e2e1'
  tertiary-fixed-dim: '#c8c6c6'
  on-tertiary-fixed: '#1b1c1c'
  on-tertiary-fixed-variant: '#474747'
  background: '#121414'
  on-background: '#e2e2e2'
  surface-variant: '#333535'
typography:
  display-lg:
    fontFamily: Georama
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Georama
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Georama
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  title-md:
    fontFamily: Georama
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-md:
    fontFamily: Georama
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-sm:
    fontFamily: Georama
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  data-tabular:
    fontFamily: Georama
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 40px
  container-max: 1280px
  gutter: 12px
---

## Brand & Style
The design system is engineered for high-performance sports data environments where speed of comprehension is the primary metric. The brand personality is authoritative, energetic, and precise—mimicking the intensity of live competition while maintaining the cool objectivity of professional analysis.

The aesthetic follows a **Modern Corporate** direction with **minimalist** constraints. It prioritizes information density without sacrificing clarity, using structured data grids, rhythmic verticality, and sharp visual hierarchies. It evokes an emotional response of reliability and "expert-mode" capability, ensuring users feel they are accessing elite-level insights.

## Colors
The color strategy utilizes a high-contrast dark theme to ensure maximum legibility of data points under varying light conditions. 

- **Primary:** A high-vibrancy "Pitch Green" (#00FF85) used exclusively for active states, key CTAs, and positive performance indicators.
- **Surface Palette:** The background utilizes a deep black (#050505) to provide a "void" for content to sit on, while containers use secondary (#1A1A1A) and tertiary (#2E2E2E) shades to create logical grouping through value shifts rather than borders.
- **Accents:** Functional colors (Red for losses/danger, Amber for warnings/draws) should be desaturated to prevent visual fatigue, allowing the Primary Green to remain the dominant focal point.

## Typography
This design system utilizes **Georama** for all levels to take advantage of its extensive weight range and technical clarity. 

- **Data Density:** For scores, statistics, and clock timers, use the `data-tabular` style which utilizes tabular figures to ensure numbers align perfectly in vertical columns.
- **Hierarchy:** Use heavy weights (700-800) for headers to provide a strong structural "anchor" for the page. 
- **Labels:** Small labels use uppercase with tracking (+0.05em) to maintain legibility at high densities.

## Layout & Spacing
The layout follows a **Fluid-Fixed Hybrid** model. Content is contained within a 1280px max-width on desktop but scales fluently on smaller breakpoints.

- **The 4px Grid:** All spacing must be a multiple of 4px. This allows for the "breathable high-density" look.
- **Information Density:** Use tight spacing (4px or 8px) within data groups (e.g., a match scoreline) and larger spacing (24px+) between logical sections (e.g., between "Live Scores" and "League Table").
- **Mobile:** Margins reduce to 16px. Use horizontal scrolling "chips" for categories to maximize vertical real estate for data lists.

## Elevation & Depth
In this design system, depth is communicated through **Tonal Layering** rather than traditional shadows to maintain a clean, professional "dashboard" feel.

- **Level 0 (Base):** Pure Black (#050505). Used for the global background.
- **Level 1 (Surface):** Dark Gray (#1A1A1A). Used for main content cards and list items.
- **Level 2 (Interaction):** Medium Gray (#2E2E2E). Used for hover states and nested UI elements like input fields.
- **Dividers:** Use subtle 1px borders (#FFFFFF at 5% opacity) only when tonal shifts are insufficient to separate high-density data rows.

## Shapes
The shape language is **Soft** but disciplined. 

- **Cards & Containers:** Use a 4px (0.25rem) corner radius. This provides a modern touch while maintaining the structural integrity of a grid-heavy layout.
- **Status Indicators:** Live indicators (e.g., a "Live" minute marker) should use a 2px radius or be sharp to feel more like a technical "readout."
- **Interactive Elements:** Buttons and Inputs follow the standard 4px radius to match the container language.

## Components
- **Data Rows:** Standardize list items with a 56px minimum height. Use a subtle hover state (#2E2E2E) and a 1px bottom divider.
- **Primary Buttons:** High-contrast pitch green (#00FF85) with black text. Use bold Georama for the label. No shadows; use a 1px inset glow for depth if needed.
- **Score Chips:** Compact containers with heavy font weights. Use a dark tertiary background (#2E2E2E) for finished matches and the primary green for live matches.
- **Input Fields:** Flat styling. No background color, only a 1px border (#2E2E2E). On focus, the border transitions to the Primary Green.
- **Segments/Tabs:** Use "Pill" style indicators for filtering. Active state: Pitch Green text with a subtle underline or filled background; Inactive: White text at 60% opacity.
- **Stat Bars:** Use thin, horizontal bars to represent data distribution (e.g., possession). Use Primary Green vs. a Neutral Gray for clear contrast.